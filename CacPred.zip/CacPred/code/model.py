# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import torch
import torch.nn.functional as F
import torch.nn as nn
class basicblock(nn.Module):
    def __init__(self):
        super(BasicBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=32, kernel_size=[4,20]),
            nn.MaxPool1d(kernel_size=100,stride=100),
        )
        self.maxpool=nn.MaxPool1d(kernel_size=100,stride=100)
        self.Linear1 = nn.Linear(9*32,50)
    def forward(self, x):
        x = self.block(x)
        conv1= torch.squeeze(x,dim=2)
        conv1 = F.relu(conv1)
        maxpool1=self.maxpool(conv1)
        fc1=maxpool1.view(-1,32*9)
        fc1=torch.sigmoid(self.Linear1(fc1))
        max1,_=torch.max(fc1,dim=1)
        return max1
class model3(nn.Module):
    def __init__(self, ):
        super(model, self).__init__()
        self.basicblock1 = basicblock()
        self.basicblock2 = basicblock()
    def forward(self, input1,input2):
        max1=basicblock1(input1)
        max2=basicblock1(input2)
        #########################
        max12,_=torch.max(torch.cat((torch.unsqueeze(max2,dim=1),torch.unsqueeze(max1,dim=1)),dim=1),dim=1)
        return max12        
        
        

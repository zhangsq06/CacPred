# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os 
for i in range(200,400):
    cmd='python train.py --index '+str(i)
    os.system(cmd)
    print(i)
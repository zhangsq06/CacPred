# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 19:23:14 2019

@author: shuangquanzhang
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import util
import numpy as np
from compute_meme import obtain
import os
import argparse
from  model import model
#######################################
SEED = 1
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)
##################inputs name####################
#parser=argparse.ArgumentParser(description='demo')
#parser.add_argument('--name',type=int,default='')
#args=parser.parse_args()
#######################       
def paddata(train_sequences):
    train_data_array = {}
    train_sequences_array = util.oneHot_data_encode(train_sequences)
    alldata=train_sequences_array[:120]
    alldata=np.transpose(alldata,axes=[0,3,2,1])
    alldata=torch.from_numpy(alldata)
    return alldata
#########################
def obtain_motifs(ii):
    path='/data/models/TEST/CCNN/model3c/'
    files=os.listdir(path)
    name=files[ii]
    name = name.split('.')[0]
    train_sequences, train_sequences_alph,reverse_sequences,reverse_alph = util.load_data_encode(path_curr_data='../data/',data_path='/data/models/basset690/data/encode_1001/'+name[:]+'_AC.seq.gz')
    print(train_sequences.shape,reverse_sequences.shape)
    traindata=paddata(train_sequences)
    reversedata=paddata(reverse_sequences)
    ##############################
    deep=model()
    Model=torch.load(path+name+'.pkl')
    model_dict = deep.state_dict()  
    
    pretrained_dict = {k: v for k, v in Model.items() if k in model_dict}  
    #print(pretrained_dict['DenseBlock.layer.2.block.2.bias'])
    model_dict.update(pretrained_dict)

    signal=np.squeeze(deep(traindata,reversedata).detach().numpy())
    print(signal.shape)
    ################################
    path='/data/models/TEST/CCNN/motifs/'+name[:]
    if not os.path.exists(path):
        os.mkdir(path)
    ################################
    pp=0
    for j in range(signal.shape[1]):
        seqname=path+'/filter_'+str(j)+'.txt'
        faname=path+'/filter_'+str(j)+'.fa'
        file1=open(seqname,'w')
        file2=open(faname,'w')
        for i in range(signal.shape[0]):
            indxx=signal[i,j,:]
            index=indxx.argmax()
            
            if indxx[index]>0 and index>450 and index <550:
                pp+=1
                seq=str(train_sequences_alph[i]).strip('\n')[int(index-15):int(index)]
                file1.writelines(seq+'\n')
                strs='>'+'seq'+'_'+str(pp)+'_'+str(i+1)+'_'+str(index)+'_'+str(15)+'\n'
                file2.writelines(strs)
                file2.writelines(seq+'\n')              
        pp=0
######################################        
        file1.close()     
        file2.close()
    obtain(path,88)
if __name__=='__main__':
#    obtain_motifs(ii=args.name)
    for i in range(700):
        obtain_motifs(ii=i)
        print(i)
from __future__ import division
import sys
import os
import gzip
import csv
import random
import numpy as np
#from constants import *
#import tensorflow as tf
import collections

SEQUENCE_WIDTH=4
SEED=0
BASE_NUM=4
# The base-num pairs
BASE_NUM = {'A' : 1, 
            'C' : 2,
            'G' : 3,
            'T' : 4,
            'N' : 0
           }

reverse={'A' : 'T', 
         'C' : 'G',
         'T' : 'A',
         'G' : 'C',
         'N' : 'N'
           }



# Get human genome sequence and shape
#path_genome = PATH_DATA + '/GRCh37.p13.genome.fa'    # Fasta files of Release 19 (GRCh37.p13)
genome_seq = {}                                      # Human genome sequence, where key = chromosome id, value = sequence
genome_shape = collections.defaultdict(dict)         # Human genome shape, where key = chromosome id, value = DNA shape
chrom_seqSize = {}                                   # Size of each chromosome, where key = chromosome id, value = length


# Make dir if the given path is not exist
def make_dir(dir_path):
    if not os.path.exists(dir_path):
        os.mkdir(dir_path)


# Load sequences, targets, and DNA shapes from ENCODE
def load_data_encode(path_curr_data,data_path):
#    if not os.path.exists(path_curr_data + "/" + "sequences.npy"):
        # Read the sequence file
    with gzip.open(data_path, 'rt') as f:
        sequenceList = list(csv.reader(f,delimiter = '\t')) 
        # Sequences (numpy array)
        sequences = np.array([[float(BASE_NUM[x]) for x in sequenceList[i][2]] for i in range(1, len(sequenceList))])

        # Sequences ('A', 'T', 'C', 'G')
        sequences_alph = [sequenceList[i][2] for i in range(1, len(sequenceList))]

        # Targets (0/1)
        targets = np.array([int(sequenceList[i][3]) for i in range(1, len(sequenceList))])
        ###################REVERSE##########################
        reverse_alph=sequences_alph
        
        reverse_alph=[[''.join(reverse[x]) for x in sequences_alph[i]][::-1] for i in range(len(sequences_alph))]
        reverse_sequences = np.array([[float(BASE_NUM[x]) for x in reverse_alph[i]] for i in range(0, len(reverse_alph))])

    return sequences, sequences_alph,reverse_sequences,reverse_alph


# Add appendix to the given data
def add_appendix(data, appendix_base, FILTER_LENGTH):
    new_data = np.ndarray(shape = (data.shape[0], data.shape[1] + 2 * (FILTER_LENGTH - 1), data.shape[2], data.shape[3]), dtype = np.float32)
    appendix = appendix_base * np.ones((FILTER_LENGTH - 1, data.shape[2]))

    for i in range(data.shape[3]):
        new_data[..., i] = np.array([np.concatenate((appendix, seq_array, appendix), axis = 0) for seq_array in data[..., i]])
    return new_data


# Convert sequences to one-hot format
def oneHot_data_encode(sequences):
    return (np.arange(1, SEQUENCE_WIDTH + 1) == sequences.flatten()[:, None]).astype(np.float32).reshape(len(sequences), sequences.shape[1], SEQUENCE_WIDTH)[..., None]
#

#if __name__=='__main__':
#    path_curr_data=''
#    sequences, targets, sequences_alph=load_data_encode(path_curr_data,'E:/motif/quan/1附件/ELK1_GM12878_ELK1_Stanford_B.seq.gz')
#    

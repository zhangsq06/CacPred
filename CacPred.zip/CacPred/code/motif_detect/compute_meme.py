# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 11:23:00 2019

@author: shuangquanzhang
"""

import numpy as np
import os
from collections import Counter
def read_fa(fa):
    alph='ACGT'
    file=open(fa,'r')
    data=file.readlines()
    file.close()
    nrow=len(data[1].strip('\n'))
    ncol=len(data)
    matrix=[]
    for i in range(nrow):
        tt=[t[i] for t in data[:]]
        nums=Counter(tt)
        num=[nums[t] for t in alph]
        matrix.append(num)
    matrix=np.array(matrix)
    alength=len(alph)
    w=nrow
    nsites=ncol
    matrix=np.array(matrix,dtype=np.float32)
    matt=np.zeros_like(matrix)
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            if j<3:
                matt[i,j] = np.around(matrix[i,j]/ncol,20)
            if j==3:
                aa=1-(matt[i,0]+matt[i,1]+matt[i,2])
                matt[i,-1]=aa 
    return matt,alength,w,nsites


def get_meme(fa):
    names=fa.split('txt')[0]
    name=names+'meme'
    matrix,alength,w,nsites=read_fa(fa)
    matrix=np.around(matrix,6)
    letter = 'letter-probability matrix: alength= '+str(alength)+' w= '+str(w)+' nsites= '+str(nsites)+'\n'
    file = open(name,'w')
    file.writelines('MEME version 4'+'\n')
    file.writelines('ALPHABET= ACGT'+'\n')
    file.writelines('MOTIF '+'motif1'+'\n')
    file.writelines('\n')
    file.writelines(letter)
    s=''
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            s+=str(matrix[i,j])+'\t'
            
        file.writelines(s+'\n')
        s=''
    file.close()
#    return names  
def obtain(path,l):
    
    for i in range(0,l):
        try:
            
            names=path+'/filter_'+str(i)+'.txt'
            get_meme(names)
        except Exception as e:
            pass 
        continue
        
    
if __name__=='__main__':
    name='E:/Motif/deeplearning/DL/Codedata/12.deepHistone/motifs/HBCx22group1'
    obtain(name,128)
#    cmd=' tomtom -no-ssc -oc ./tomtom -verbosity 1 -min-overlap 5 -mi 1 -dist pearson -thresh 0.01 -norc '+name+'.meme  HOCOMOCOv11_core_HUMAN_mono_meme_format.meme'
#    os.system(cmd)
#    cmd='mv ./tomtom/tomtom.html '+name+'.html'
#    os.system(cmd)
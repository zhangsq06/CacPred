# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 15:01:55 2019

@author: shuangquanzhang
"""
import torch
import torch.optim as optim
import numpy as np
import torch.nn as nn
import torch.utils.data as Data
from util import convert_data
from auc import com_auc
from model2 import model2
from model3 import model3
import argparse
import time
torch.manual_seed(1)
np.random.seed(1)
torch.cuda.current_device()
torch.cuda._initialized = True
parser = argparse.ArgumentParser(description='input some paras.')
parser.add_argument('--index',default=0,type=int)
parser.add_argument('--m',default='model3',type=str)
args = parser.parse_args()
EPOCH = 20
LR = 5e-2
start_time=time.time()

directx,directy,reversex,name = convert_data(args.index,flag='train')
directx,reversex=directx[:,np.newaxis,:,:],reversex[:,np.newaxis,:,:]
directy=np.squeeze(directy)
print(directx.shape,directy.shape)

validX1_data = torch.FloatTensor(directx[1000:])
validX2_data = torch.FloatTensor(reversex[1000:])        
validY_data = torch.FloatTensor(directy[1000:])

direct_validx = torch.FloatTensor(directx[:1000])
reverse_validx = torch.FloatTensor(reversex[:1000])
direct_validy=torch.FloatTensor(directy[:1000])

params = {'batch_size': 100}
train_loader = Data.DataLoader(
    dataset=Data.TensorDataset(validX1_data,validX2_data, validY_data), 
    shuffle=False,
    **params)
print('compling the network')
###########################################################################
if args.m=='model2':
    MODEL=model2()
if args.m=='model3':
    MODEL=model3()

MODEL.cuda()
optimizer = optim.Adadelta(MODEL.parameters(), lr=LR)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=3,verbose=True)
loss_func = nn.BCELoss()        
print('starting training')
val_loss=10        
for epoch in range(EPOCH):
    MODEL.train(mode=True)
    for step, (direct_batch_x,reverse_batch_x, train_batch_y) in enumerate(train_loader):       
        direct_batch_x = direct_batch_x.cuda()
        reverse_batch_x = reverse_batch_x.cuda()
        train_batch_y = train_batch_y.cuda()

        out = MODEL(direct_batch_x,reverse_batch_x)
        loss = loss_func(out, train_batch_y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
#    print('training loss:',loss.item())
    if epoch % 10 ==0:
        with torch.no_grad():
            for i,j in zip(range(0,direct_validx.shape[0],100),range(100,direct_validx.shape[0]+100,100)):
                valout =MODEL(direct_validx[i:j].cuda(),reverse_validx[i:j].cuda())
                valout=valout
                if i==0:
                    val_out=valout
                else:
                    val_out=torch.cat((val_out,valout),0)      
            valid_loss = loss_func(val_out, direct_validy.cuda())
            scheduler.step(valid_loss)
            val_auc,_,_,_ = com_auc(direct_validy.data.cpu().numpy(),val_out.data.cpu().numpy())
            print('valid_loss: %f ' % valid_loss.data.cpu().numpy())

model_name='../model/'+name+'.pkl'
torch.save(MODEL.state_dict(), model_name)
end_time=time.time()
total_time=np.expand_dims(np.array(end_time-start_time),0)
out_time='../output/'+name+'.txt'
np.savetxt(out_time,total_time)   
############################################
out_name='../output/'+name+'_validation.txt'
np.savetxt(out_name,[direct_validy.data.cpu().numpy(),val_out.data.cpu().numpy()])

#################################################################################################
print('.....testing.........')
direct_testx,direct_testy,reverse_testx,_ = convert_data(args.index,flag='test')
direct_testx,reverse_testx=direct_testx[:,np.newaxis,:,:],reverse_testx[:,np.newaxis,:,:]
direct_testy=np.squeeze(direct_testy)
print(direct_testx.shape,direct_testy.shape)
direct_testx=torch.FloatTensor(direct_testx)
reverse_testx=torch.FloatTensor(reverse_testx)
##################################################################################################
with torch.no_grad():
    for i,j in zip(range(0,direct_testx.shape[0],100),range(100,direct_testx.shape[0]+100,100)):
        testout = MODEL(direct_testx[i:j].cuda(),reverse_testx[i:j].cuda())
        testout=testout.data.cpu().numpy()
        if i==0:
            test_out=testout
        else:
            test_out=np.concatenate((test_out,testout),0)
        testout=[]
################################################################################################## 
test_auc,_,_,_ = com_auc(np.array(direct_testy),test_out)
print('test_auc: %f ' % test_auc)

out_name='../output/'+name+'.txt'
np.savetxt(out_name,[np.array(direct_testy),test_out])
